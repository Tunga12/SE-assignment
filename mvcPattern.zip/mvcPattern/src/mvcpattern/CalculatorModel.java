/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvcpattern;

/**
 *
 * @author user1
 */
public class CalculatorModel {
    
    private double calculationValue;

    public void addTwoNumbers(double firstNumber, double secondNumber){
        calculationValue = firstNumber + secondNumber;
    }
    
    public void sub(double firstNumber, double secondNumber){
        calculationValue = firstNumber - secondNumber;
    }
    
    public void div(double firstNumber, double secondNumber){
        calculationValue = firstNumber / secondNumber;
    }
    
    public void mul(double firstNumber, double secondNumber){
        calculationValue = firstNumber * secondNumber;
    }

    public double getCalculationValue(){
        return calculationValue;
    }
    
}
