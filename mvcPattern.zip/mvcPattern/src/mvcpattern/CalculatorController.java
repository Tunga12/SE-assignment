/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvcpattern;

/**
 *
 * @author user1
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class CalculatorController {
    
    private ViewCalc theView;
    private CalculatorModel theModel;

    public CalculatorController(ViewCalc theView) {
        this.theView = theView;
        this.theModel = new CalculatorModel();

        // Tell the View that when ever the calculate button
        // is clicked to execute the actionPerformed method
        // in the CalculateListener inner class

//        this.theView.addCalculateListener(new CalculateListener());
    }
    
    public  void button_click(ActionEvent evt){
        
        System.out.println("Got in button_click");
        System.out.println(theView.getTextBox());
        
        if ((theView.getTextBox().equals("0")) || (theView.getIsOperationPerformed()))
                theView.setTextBox("");

            theView.setIsOperationPerformed(false);
            JButton button = (JButton) evt.getSource();
            if (button.getText().equals("."))
            {
                if (!theView.getTextBox().contains("."))
                    theView.setTextBox(theView.getTextBox() + button.getText()); 

            }
            else
                theView.setTextBox(theView.getTextBox() + button.getText()); 
    }
    
    public void operator_click(ActionEvent evt){
        
        System.out.println("Got in operator_click");
                
        JButton button = (JButton)evt.getSource();
            
            if (theView.getResult() != 0)
            {
                theView.setOperationPerformed(button.getText());
                theView.setLabel(theView.getResult()+ " " + theView.getOperationPerformed());
                theView.setIsOperationPerformed(true);
            }
            else
            {
                theView.setOperationPerformed(button.getText());
                theView.setResult(Double.parseDouble(theView.getTextBox()));
                theView.setLabel(theView.getResult()+ " " + theView.getOperationPerformed());
                theView.setIsOperationPerformed(true);
            }
    }
    
    
    public void equal_click(ActionEvent evt){
        
        System.out.println("Got in equal_click");

        
        switch (theView.getOperationPerformed())
            {
                case "+":
                    // send the resultValue and the textBox1 value to the controller
                    theModel.addTwoNumbers(theView.getResult(), Double.parseDouble(theView.getTextBox()));
                    theView.setTextBox(String.valueOf(theModel.getCalculationValue()));
                    break;
                case "-":
                    theModel.sub(theView.getResult(), Double.parseDouble(theView.getTextBox()));
                    theView.setTextBox(String.valueOf(theModel.getCalculationValue()));
                    break;
                case "*":
                    theModel.mul(theView.getResult(), Double.parseDouble(theView.getTextBox()));
                    theView.setTextBox(String.valueOf(theModel.getCalculationValue()));
                    break;
                case "/":
                    theModel.div(theView.getResult(), Double.parseDouble(theView.getTextBox()));
                    theView.setTextBox(String.valueOf(theModel.getCalculationValue()));
                    break;
                default:
                    break;
            }

            theView.setResult(Double.parseDouble(theView.getTextBox()));
            theView.setLabel("");
            theView.setIsOperationPerformed(true);
    }
    
    public void C_click(java.awt.event.ActionEvent evt) {                         
        theView.setTextBox("0");
        theView.setResult(0);
        theView.setLabel("");
        
    }                        

    public void CE_click(java.awt.event.ActionEvent evt) {                          
        theView.setTextBox("0");
        theView.setLabel("");
    }                         

    

}
